<?php
namespace Vleks\BolPlazaSDK\Results;

use Vleks\BolPlazaSDK\Entity;

class AccountingPartyName extends Entity
{
    protected $fields = [
        'Name' => ['value' => null, 'type' => 'string']
    ];
}