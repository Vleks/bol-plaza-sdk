<?php
namespace Vleks\BolPlazaSDK\Exceptions;

class ServiceException extends ClientException
{
    //
}
