<?php
namespace Vleks\BolPlazaSDK\Exceptions;

use \Exception;

class ClientException extends Exception
{
    //
}
