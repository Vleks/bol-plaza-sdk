<?php
namespace Vleks\BolPlazaSDK\Exceptions;

use \Exception;

class EntityException extends Exception
{
}
