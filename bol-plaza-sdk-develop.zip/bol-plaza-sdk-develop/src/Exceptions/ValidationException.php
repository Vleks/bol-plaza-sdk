<?php
namespace Vleks\BolPlazaSDK\Exceptions;

class ValidationException extends ClientException
{
    //
}
