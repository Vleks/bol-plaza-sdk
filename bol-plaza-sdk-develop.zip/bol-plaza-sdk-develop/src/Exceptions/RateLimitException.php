<?php
namespace Vleks\BolPlazaSDK\Exceptions;

class RateLimitException extends ClientException
{
    //
}
