<?php
namespace Vleks\BolPlazaSDK\Enumerables;

class ProductlabelFormat extends Enumerable
{
    const AVERY_J8159           = 'AVERY_J8159';
    const AVERY_J8160           = 'AVERY_J8160';
    const AVERY_3474            = 'AVERY_3474';
    const DYMO_99012            = 'DYMO_99012';
    const BROTHER_DK11208D      = 'BROTHER_DK11208D';
    const ZEBRA_Z_PERFORM_1000T = 'ZEBRA_Z_PERFORM_1000T';
}
