<?php
namespace Vleks\BolPlazaSDK\Enumerables;

class Transporters extends Enumerable
{
    //
}
