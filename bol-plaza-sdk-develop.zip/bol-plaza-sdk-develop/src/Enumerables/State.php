<?php
namespace Vleks\BolPlazaSDK\Enumerables;

class State extends Enumerable
{
    const ANNOUNCED   = 'Announced';
    const UNANNOUNCED = 'Unannounced';
}
