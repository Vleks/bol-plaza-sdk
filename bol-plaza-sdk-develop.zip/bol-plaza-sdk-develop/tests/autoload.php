<?php

require realpath(dirname(__DIR__)) . '/vendor/autoload.php';
